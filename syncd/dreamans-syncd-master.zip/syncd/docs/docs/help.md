# 获取帮助

Syncd使用交流QQ群①: 725302833

[filename](include/footer.md ':include')