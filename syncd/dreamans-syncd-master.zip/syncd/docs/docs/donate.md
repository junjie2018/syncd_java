# 捐赠我们

Syncd 一直在致力于为企业和个人提供简洁高效的持续集成工具，您的帮助是对我们最大的支持和动力！

### 扫码捐赠

<div class="app-donate">
    <img class="app-wechat-donate" src="../assets/img/wechat-donate.png" />
    <span class="tit">微信扫码捐赠</span>
</div>

### 捐赠列表

| Name         | Date       | Amount  | Via    | Note                 |
| ------------ | ---------- | ------- | ------ | -------------------- |
| lizhibo      | 2019-04-11 |  ¥68.88 | Wechat |                      |
| k8svip       | 2019-04-01 | ¥100.00 | Wechat |                      |

[filename](include/footer.md ':include')
