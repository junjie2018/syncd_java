<template>
    <el-card>
        <p>Dashboard Coming Soon...</p>
        <p style="margin-top: 100px;"><i style="font-size:48px; color:#409EFF" class="iconfont icon-working"></i></p>
    </el-card>
</template>