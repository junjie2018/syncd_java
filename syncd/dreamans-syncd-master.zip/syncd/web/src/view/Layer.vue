<template>
    <div class="layer-global">
        <header class="layer-header">
            <div class="header-left">
                <div class="logo">
                    <svg class="svg-logo" viewBox="0 0 614 140" fill="currentColor" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                        <g stroke="none" stroke-width="1" fill="currentColor" fill-rule="evenodd">
                            <g fill="currentColor">
                                <path d="M76.341871,54.9711233 C79.6727636,55.1713762 82.9820174,54.3261506 85.7875581,52.5585745 C87.9644519,50.8849708 89.1594685,48.270408 88.9828351,45.5676661 C89.0520286,43.5875142 88.4071238,41.6466195 87.1609667,40.0846007 C85.3315316,38.2011549 83.0753476,36.7643829 80.5742115,35.8900557 C78.7144909,35.2368252 76.9663284,34.3125531 75.3888936,33.148523 C74.7308386,32.5642884 74.3459664,31.7420443 74.3238013,30.8730508 C74.3163858,29.8308384 74.9137957,28.8746531 75.8653823,28.4056714 C77.1197351,27.7451499 78.5347275,27.4323224 79.9575791,27.5009656 C82.6836673,27.4382889 85.3639311,28.1941532 87.6374553,29.6667764 L87.6374553,23.2241746 C85.0625605,22.3488199 82.3460583,21.9400429 79.6212342,22.0179002 C76.3751267,21.8620855 73.1632656,22.7267374 70.4558344,24.4852796 C68.181472,26.0658664 66.8830821,28.6677647 67.0082988,31.3939421 C67.0082988,35.4331336 69.5495717,38.5036502 74.6321175,40.6054919 C76.7692114,41.3336199 78.7747957,42.3884917 80.5742115,43.7308392 C81.2651955,44.365686 81.6687321,45.2439048 81.6953613,46.1708033 C81.6948692,47.1817147 81.1522708,48.1182856 80.2658953,48.6381828 C78.9725983,49.3594956 77.4911003,49.6931642 76.005526,49.5977192 C72.731232,49.6232175 69.5571068,48.4942508 67.0643563,46.4175413 L67.0643563,53.2165424 C69.9722962,54.5083132 73.1512166,55.1095165 76.341871,54.9711233 Z"></path>
                                <path d="M7.64753123,46.3115351 L71.0793317,77.5530362 C75.4182301,79.4823213 80.3644808,79.4823213 84.7033792,77.5530362 L148.245496,46.3115351 C151.098572,45.2756019 153,42.5515231 153,39.5 C153,36.4484769 151.098572,33.7243981 148.245496,32.6884649 L84.8136954,1.44696381 C80.4747969,-0.48232127 75.5285463,-0.48232127 71.1896478,1.44696381 L7.7578474,32.6884649 C4.92182396,33.7252726 3.02482306,36.4258698 3.00024162,39.4614596 C2.97566018,42.4970493 4.8286747,45.228381 7.64753123,46.3115351 Z M75.6022948,9.54866747 C77.1205951,9.01798216 78.7724319,9.01798216 80.2907322,9.54866747 L141.074944,39.5416183 L80.4010484,69.5068237 C78.8827481,70.037509 77.2309113,70.037509 75.712611,69.5068237 L14.6801874,39.5416183 L75.6022948,9.54866747 Z" fill-rule="nonzero"></path>
                                <path d="M2.50434289,73.4935962 L75.5649644,109.546033 C76.7918235,110.151322 78.2284179,110.151322 79.455277,109.546033 L152.681444,73.4935962 C154.769102,72.3609991 155.592914,69.7724576 154.546834,67.6322617 C153.500754,65.4920658 150.958863,64.565555 148.791131,65.5343274 L77.4963253,100.671587 L6.39465545,65.4511294 C4.18514309,64.3713292 1.52310334,65.2963456 0.448823201,67.5172114 C-0.625456935,69.7380773 0.294830573,72.4137959 2.50434289,73.4935962 Z"></path>
                                <path d="M148.89106,95.9074966 L77.4591793,130.797939 L6.22080626,95.7418774 C4.04890686,94.7776268 1.50212826,95.6998131 0.454037138,97.8300193 C-0.594053987,99.9602256 0.231342389,102.536685 2.32301402,103.663995 L75.5241052,139.548152 C76.753323,140.150616 78.1926795,140.150616 79.4218974,139.548152 L152.788852,103.663995 C154.500194,103.177108 155.752688,101.713584 155.967527,99.9497499 C156.182367,98.1859159 155.317712,96.4652771 153.773139,95.5829791 C152.228567,94.7006811 150.304881,94.8285508 148.89106,95.9074966 Z"></path>
                            </g>
                            <path d="M294.68,64.8 C298.920021,69.0400212 301.04,74.8799628 301.04,82.32 L301.04,92.52 C301.04,98.0400276 299.120019,102.79998 295.28,106.8 C291.519981,110.72002 286.840028,112.68 281.24,112.68 L231.08,112.68 L231.08,105.48 L281.24,105.48 C284.840018,105.48 287.799988,104.240012 290.12,101.76 C292.600012,99.2799876 293.84,96.2000184 293.84,92.52 L293.84,82.32 C293.84,71.919948 288.640052,66.320004 278.24,65.52 L250.76,63.36 C242.919961,62.3999952 237.320017,60.6800124 233.96,58.2 C231.479988,56.3599908 229.720005,53.9600148 228.68,51 C227.559994,48.199986 227,44.600022 227,40.2 L227,30.6 C227,25.0799724 228.919981,20.32002 232.76,16.32 C236.68002,12.3999804 241.359973,10.44 246.8,10.44 L295.04,10.44 L295.04,17.64 L246.8,17.64 C243.199982,17.64 240.240012,18.8799876 237.92,21.36 C235.439988,24.0000132 234.2,27.0799824 234.2,30.6 L234.2,40.2 C234.2,46.20003 235.599986,50.2799892 238.4,52.44 C240.560011,54.2000088 244.919967,55.4399964 251.48,56.16 L278.84,58.32 C285.560034,58.9600032 290.839981,61.1199816 294.68,64.8 Z M353.16,103.2 L377.4,40.32 L385.08,40.32 L351.12,128.64 C349.919994,132.000017 347.800015,134.67999 344.76,136.68 C341.639984,138.68001 338.360017,139.68 334.92,139.68 L325.2,139.68 L325.2,132.48 L334.92,132.48 C337.080011,132.48 338.999992,131.880006 340.68,130.68 C342.440009,129.559994 343.679996,128.04001 344.4,126.12 L349.32,113.16 L321.48,40.32 L329.16,40.32 L353.16,103.2 Z M453.76,46.8 C456.960016,50.3200176 458.56,55.3199676 458.56,61.8 L458.56,114.36 L451.36,114.36 L451.36,61.8 C451.36,57.2399772 450.36001,53.8400112 448.36,51.6 C446.519991,49.59999 443.800018,48.6 440.2,48.6 L411.28,48.6 L411.28,114.36 L404.08,114.36 L404.08,41.4 L440.2,41.4 C445.880028,41.4 450.399983,43.199982 453.76,46.8 Z M494.24,54.6 C490.639982,58.200018 488.84,62.5599744 488.84,67.68 L488.84,88.68 C488.84,93.1600224 490.479984,97.1199828 493.76,100.56 C497.040016,103.840016 500.999977,105.48 505.64,105.48 L536,105.48 L536,112.68 L505.64,112.68 C498.919966,112.68 493.280023,110.320024 488.72,105.6 C483.999976,100.879976 481.64,95.2400328 481.64,88.68 L481.64,67.68 C481.64,60.6399648 484.159975,54.6000252 489.2,49.56 C494.080024,44.5199748 500.119964,42 507.32,42 L536,42 L536,49.2 L507.32,49.2 C502.199974,49.2 497.840018,50.999982 494.24,54.6 Z M606.6,9 L613.8,9 L613.8,112.68 L578.64,112.68 C571.919966,112.68 566.280023,110.320024 561.72,105.6 C556.999976,100.879976 554.64,95.2400328 554.64,88.68 L554.64,67.68 C554.64,60.479964 557.159975,54.4400244 562.2,49.56 C567.080024,44.5199748 573.119964,42 580.32,42 L598.92,42 L598.92,49.2 L580.32,49.2 C575.199974,49.2 570.840018,50.999982 567.24,54.6 C563.639982,58.200018 561.84,62.5599744 561.84,67.68 L561.84,88.68 C561.84,93.1600224 563.479984,97.1199828 566.76,100.56 C570.040016,103.840016 573.999977,105.48 578.64,105.48 L606.6,105.48 L606.6,9 Z" fill="currentColor"></path>
                        </g>
                    </svg>
                </div>
            </div>
            <div class="header-right">
                <span class="r-item">
                    <el-dropdown trigger="click">
                        <span class="item app-cursor">
                            <i class="iconfont icon-question-circle-fill"></i>
                            <i class="iconfont small icon-arrow-down"></i>
                        </span>
                        <el-dropdown-menu slot="dropdown" class="app-header-dropdown">
                            <a class="app-dropdown-link" href="https://github.com/dreamans/syncd/issues" target="_blank">
                                <el-dropdown-item><i class="iconfont small left icon-help"></i>{{ $t('help') }}</el-dropdown-item>
                            </a>
                            <a class="app-dropdown-link" href="https://github.com/dreamans/syncd" target="_blank">
                                <el-dropdown-item><i class="iconfont small left icon-pull-request"></i>{{ $t('contribute_to_syncd') }}</el-dropdown-item>
                            </a>
                        </el-dropdown-menu>
                    </el-dropdown>
                </span>
                <span class="r-item">
                    <el-dropdown trigger="click" @command="userSettingHandler">
                        <span class="item app-cursor">
                            <img class="avatar" :src="$store.getters['account/getAvatar']" />
                            <i class="iconfont small icon-arrow-down"></i>
                        </span>
                        <el-dropdown-menu slot="dropdown" class="app-header-dropdown">
                            <el-dropdown-item class="text"><i class="iconfont small left icon-user"></i>{{ $store.getters['account/getUserName'] }}</el-dropdown-item>
                            <el-dropdown-item command="setting" divided><i class="iconfont small left icon-setting"></i>{{ $t('personal_setting') }}</el-dropdown-item>
                            <el-dropdown-item command="password"><i class="iconfont small left icon-key"></i>{{ $t('change_password') }}</el-dropdown-item>
                            <el-dropdown-item command="logout" divided><i class="iconfont small left icon-logout"></i>{{ $t('sign_out') }}</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </span>
            </div>
        </header>
        <section class="layer-container">
            <aside class="layer-aside">
                <ScrollBar>
                    <el-menu class="aside-menu" :default-active="activeMenu" :router="true" :unique-opened="true">
                        <template v-for="menu in AppMenu">
                            <el-submenu v-if="menu.children && (menu.children.length > 1 || (menu.children.length == 1 && !menu.children[0].meta.single))" :index="menu.name" :key="menu.name">
                                <template slot="title">
                                    <span v-if="menu.meta.icon" class="iconfont left" :class="menu.meta.icon"></span><span>{{ menu.meta.title }}</span>
                                </template>
                                <template v-for="childMenu in menu.children">
                                    <el-menu-item v-if="!(childMenu.meta && childMenu.meta.hide)" :route="{name: childMenu.name}" :index="childMenu.name" :key="childMenu.name">
                                        <i class="iconfont small left">
                                            <svg viewBox="0 0 1024 1024" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M384.023552 384.083968l256.016384 0 0 256.016384-256.016384 0 0-256.016384Z"></path></svg>
                                        </i>
                                        <span>{{ childMenu.meta.title }}</span>
                                    </el-menu-item>
                                </template>
                            </el-submenu>
                            <el-menu-item :route="{name: menu.children[0].name}" v-else-if="menu.children && menu.children.length == 1" :index="menu.children[0].name" :key="menu.children[0].name">
                                <i v-if="menu.children[0].meta.icon" class="iconfont left" :class="menu.children[0].meta.icon"></i>
                                <span>{{ menu.children[0].meta.title }}</span>
                            </el-menu-item>
                        </template>
                    </el-menu>
                </ScrollBar>
            </aside>
            <main class="layer-main">
                <el-breadcrumb separator="/" class="bread-crumb">
                    <el-breadcrumb-item><i class="iconfont small icon-breadcrumbs"></i></el-breadcrumb-item>
                    <el-breadcrumb-item v-for="b in breadcrumb" :key="b">{{ b }}</el-breadcrumb-item>
                </el-breadcrumb>
                <div class="container">
                    <router-view/>
                    <div class="app-cpy">
                        <p>
                        ©️ {{ new Date().getFullYear() }} <a href="https://github.com/dreamans/syncd" target="_blank">Syncd</a>. All Rights Reserved. MIT License.
                        </p>
                    </div>
                </div>
            </main>
        </section>

        <el-dialog :width="$root.DialogSmallWidth" title="个人设置" :visible.sync="settingDialogVisible" @close="closeUserSettingDialogHandler">
            <el-form class="app-form" ref="settingDialogRef" :model="settingForm" size="medium" label-width="80px">
                <el-form-item 
                :label="$t('role')">
                    {{ $store.getters['account/getRoleName'] }}
                </el-form-item>
                <el-form-item 
                :label="$t('avatar')">
                    <img :src="$store.getters['account/getAvatar']" class="app-avatar normal">
                    &nbsp;<a class="app-link" href="http://cn.gravatar.com/support/activating-your-account/" target="_blank"><i class="iconfont small left icon-question"></i>如何修改头像</a>
                </el-form-item>
                <el-form-item 
                :label="$t('username')">
                    <el-input :value="$store.getters['account/getUserName']" :disabled="true"></el-input>
                    <span class="app-input-help"><i class="el-icon-info"></i> 修改用户名请联系管理员</span>
                </el-form-item>
                <el-form-item 
                :label="$t('email')">
                    <el-input :value="$store.getters['account/getEmail']" :disabled="true"></el-input>
                    <span class="app-input-help"><i class="el-icon-info"></i> 修改邮箱请联系管理员</span>
                </el-form-item>
                <el-form-item 
                :label="$t('truename')"
                prop="truename">
                    <el-input v-model="settingForm.truename"></el-input>
                </el-form-item>
                <el-form-item 
                :label="$t('mobile')"
                prop="mobile">
                    <el-input v-model="settingForm.mobile"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button size="small" @click="closeUserSettingDialogHandler">{{ $t('cancel')}}</el-button>
                <el-button :loading="btnLoading" size="small" type="primary" @click="dialogUserSettingSubmitHandler">{{ $t('enter')}}</el-button>
            </div>
        </el-dialog>
    
        <el-dialog :width="$root.DialogSmallWidth" title="修改密码" :visible.sync="passwordDialogVisible" @close="closePasswordSettingDialogHandler">
            <el-form class="app-form" ref="passwordDialogRef" :model="passwordForm" size="medium" label-width="80px">
                <el-form-item 
                :label="$t('current_password')"
                prop="password"
                :rules="[
                    { min: 6, max: 20, message: this.$t('strlen_between', {min: 6, max: 20}), trigger: 'blur'},
                    { required: true, message: this.$t('current_password_cannot_empty'), trigger: 'blur'},
                ]">
                    <el-input type="password" :placeholder="$t('please_input_password_length_limit')" v-model="passwordForm.password" autocomplete="off"></el-input>
                </el-form-item>
                <el-form-item 
                :label="$t('new_password')"
                prop="new_password"
                :rules="[
                    { min: 6, max: 20, message: this.$t('strlen_between', {min: 6, max: 20}), trigger: 'blur'},
                    { required: true, message: this.$t('new_password_cannot_empty'), trigger: 'blur'},
                ]">
                    <el-input type="password" :placeholder="$t('please_input_password_length_limit')" v-model="passwordForm.new_password" autocomplete="off"></el-input>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button size="small" @click="closePasswordSettingDialogHandler">{{ $t('cancel')}}</el-button>
                <el-button :loading="btnLoading" size="small" type="primary" @click="dialogPasswordSettingSubmitHandler">{{ $t('enter')}}</el-button>
            </div>
        </el-dialog>

    </div>
</template>

<script>
import ScrollBar from '@/component/ScrollBar';
import { routerMap } from '@/router'
import Code from '@/lib/code'
import { loginStatusApi, logoutApi } from '@/api/login'
import { userSettingApi, userPasswordApi } from '@/api/user'
export default {
    data() {
        return {
            breadcrumb: [],
            activeMenu: '',

            btnLoading: false,
            settingDialogVisible: false,
            settingForm: {},
            passwordDialogVisible: false,
            passwordForm: {},
        }
    },
    computed: {
        AppMenu() {
            let menu = []
            routerMap.forEach(first => {
                let newSecond = []
                let newFirst = Object.assign({}, first)
                first.children.forEach(second => {
                    if (!second.meta.role || this.$root.CheckPrivs(second.meta.role)) {
                        newSecond.push(second)
                    }
                })
                if (newSecond.length > 0) {
                    newFirst.children = newSecond
                    menu.push(newFirst)
                }
            })
            return menu
        }
    },
    watch: {
        '$route.name'() {
            this.breadcrumbItems()
            this.initActiveMenu()
        },
        AppMenu() {
            this.breadcrumbItems()
        },
    },
    components: {
        ScrollBar,
    },
    methods: {
        userSettingHandler(cmd) {
            switch (cmd) {
                case 'logout':
                    logoutApi().then(res => {
                        this.$router.push({name: 'login'})
                    })
                    break
                case 'setting':
                    this.showUserSettingDialogHandler()
                    break
                case 'password':
                    this.showPasswordSettingDialogHandler()
                    break
            }
        },

        showPasswordSettingDialogHandler() {
            this.passwordDialogVisible = true
        },
        closePasswordSettingDialogHandler() {
            this.passwordDialogVisible = false
        },
        dialogPasswordSettingSubmitHandler() {
            let vm = this
            this.$refs.passwordDialogRef.validate((valid) => {
                if (!valid) {
                    return false;
                }
                let postData = {
                    password: this.$root.Md5Sum(vm.passwordForm.password),
                    new_password: this.$root.Md5Sum(vm.passwordForm.new_password)
                }
                this.btnLoading = true
                userPasswordApi(postData).then(res => {
                    this.$root.MessageSuccess(() => {
                        this.btnLoading = false
                        this.closePasswordSettingDialogHandler()
                    })
                }).catch(err => {
                    if (err.code == Code.CODE_ERR_USER_OR_PASS_WRONG) {
                        this.$message({
                            message: '当前密码错误，请重新输入',
                            type: 'warning',
                        });
                    }
                    this.btnLoading = false
                })
            })
        },

        showUserSettingDialogHandler() {
            this.settingForm = {
                truename: this.$store.getters['account/getTrueName'],
                mobile: this.$store.getters['account/getMobile'],
            }
            this.settingDialogVisible = true
        },
        closeUserSettingDialogHandler() {
            this.settingDialogVisible = false
        },
        dialogUserSettingSubmitHandler() {
            this.btnLoading = true
            userSettingApi(this.settingForm).then(res => {
                this.$root.MessageSuccess(() => {
                    this.btnLoading = false
                    this.closeUserSettingDialogHandler()
                })
                this.$store.dispatch('account/userSetting', {
                    mobile: this.settingForm.mobile,
                    truename: this.settingForm.truename,
                })
            }).catch(err => {
                this.btnLoading = false
            })
        },

        initActiveMenu() {
            this.activeMenu = this.$route.name
        },
        breadcrumbItems() {
            let breadcrumb = []
            this.AppMenu.forEach(menu => {
                menu.children.forEach(sub => {
                    if (sub.name != this.$route.name) {
                        return
                    }
                    if (menu.meta.title) {
                        breadcrumb.push(menu.meta.title)
                    }
                    breadcrumb.push(sub.meta.title)
                })
            })
            this.breadcrumb = breadcrumb
        },
        initLoginStatus() {
            loginStatusApi().then(res => {
                if (res.is_login) {
                    this.$store.dispatch('account/status', {
                        user_id: res.user_id,
                        username: res.username,
                        email: res.email,
                        mobile: res.mobile,
                        privilege: res.privilege ? res.privilege : [],
                        role_name: res.role_name,
                        truename: res.truename,
                    })
                } else {
                    this.$message.error('用户未登录', 1)
                    this.$router.push({name: 'login'})
                }
            }).catch(err => {
                this.$message.error('用户未登录', 1)
                this.$router.push({name: 'login'})
            })
        },
    },
    mounted() {
        this.initLoginStatus()
        this.initActiveMenu()
    },
}
</script>
