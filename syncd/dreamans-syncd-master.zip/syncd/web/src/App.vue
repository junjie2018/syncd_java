<template>
    <div class="global-container">
        <router-view/>
    </div>
</template>

<style>
.global-container {
    width: 100%;
    height: 100%;
}
</style>